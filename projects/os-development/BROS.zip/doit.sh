#! /bin/sh

rm boot/BOS_boot.bin
rm kernel/kernel.sys
echo
echo -e "\E[33;1mBOS\E[0m - \E[32;1mLinux installer\E[0m"
echo

echo -e "\E[32mCompiling BOS...\E[0m"
./utils/fasm kernel/kernel.asm kernel/kernel.sys
./utils/fasm boot/boot.asm boot/boot.bin

	echo -e "\E[32mStarting image creation...\E[0m"
	if [ -e bos.img ]; then
		rm -f bos.img
	fi
	dd if=/dev/zero of=bos.img bs=1k count=1440
	mkdosfs bos.img
	losetup /dev/loop3 bos.img
	dd if=boot/boot.bin of=/dev/loop3 bs=1 count=512
	if [ ! -e tmpmnt ]; then
		mkdir tmpmnt
	fi
	mount -tmsdos /dev/loop3 tmpmnt
	cp kernel/kernel.sys tmpmnt
	umount /dev/loop3
	if [ -e tmpmnt ]; then
		rm -rf tmpmnt
	fi
	losetup -d /dev/loop3
	qemu -soundhw pcspk -fda bos.img

