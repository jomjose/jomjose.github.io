#! /bin/sh
umount /dev/loop3
if [ -e tmpmnt ]; then
	rm -rf tmpmnt
fi
losetup -d /dev/loop3


